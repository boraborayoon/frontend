###completion 결과 예시###

```json
{
  "id": "chatcmpl-6p9XYPYSTTRi0xEviKjjilqrWU2Ve",
  "object": "chat.completion",
  "created": 1677649420,
  "model": "gpt-3.5-turbo",
  "usage": { "prompt_tokens": 56, "completion_tokens": 31, "total_tokens": 87 },
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "The 2020 World Series was played in Arlington, Texas at the Globe Life Field, which was the new home stadium for the Texas Rangers."
      },
      "finish_reason": "stop",
      "index": 0
    }
  ]
}
```
