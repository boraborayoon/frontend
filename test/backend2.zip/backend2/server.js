require("dotenv").config();
const serverless = require("serverless-http");
const { Configuration, OpenAIApi } = require("openai");
const express = require("express");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const corsOptions = {
  origin: "https://aimpawpaw.pages.dev/",
  credentials: true,
};
app.use(cors(corsOptions));

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

app.get("/test", async (req, res) => {
  res.json({ test: "YES!" });
});

app.post("/query", async (req, res) => {
  const messageChains = req.body;
  const messages = [
    {
      role: "system",
      content:
        "당신은 세계 최고의 반려동물 전문가입니다. 특히 고양이와 개에 대해서는 어떠한 질문에 대해서 답을 할 수 있습니다. 모든 질문에 대해서 친절하고 상세하게 답을 할 수 있습니다.  당신의 이름은 아임포 입니다. 제일 처음에 어떤 동물을 키우고 있는지 부터 확인하는 질문 부터 시작을 해야 합니다. 간혹 사용자가 아기 또는 애라는 표현으로 본인이 키우는 강아지나 고양이를 표현할 때가 있습니다. 모든 답변의 토큰수는 최대 200토큰으로 제한을 합니다.",
    },
    {
      role: "assistant",
      content:
        "안녕하세요, 저는 강아지와 고양이에 대한 전세계의 지식을 기반으로 증상을 예측할 수 있는  아이엠포입니다. 여러분의 반려견 반려모와 관련된 궁금한 것을 어떤 것이든 최대한 상세히 알려 드리겠습니다. 먼저 키우고 계신 동물이 강아지인지 고양이인지 먼저 알려주시고, 이름과 나이도 같이 알려 주세요.",
    },
    ...messageChains,
  ];

  console.log(messages);

  const completion = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    max_tokens: 300,
    temperature: 0.7,
    top_p: 0.5,
    messages: messages,
  });

  const result = completion.data.choices[0].message["content"];
  res.json({ assistant: result });
});

const IP_ADDRESS = "localhost"; // replace with your desired IP address
const PORT = 3000; // replace with your desired port number

// app.listen(PORT, IP_ADDRESS, () => {
//   console.log(`Server listening on ${IP_ADDRESS}:${PORT}`);
// });

module.exports.handler = serverless(app);
